/*   */ package io.socket.parser;
/*   */ 
/*   */ public class DecodingException extends RuntimeException {
/*   */   public DecodingException(String message) {
/* 5 */     super(message);
/*   */   }
/*   */ }


/* Location:              D:\Users\imnot\OneDrive\Desktop\test\hello\module_example-0.1-26.1-0.15.4-mc1.12.1_deobfuscated.jar!\io\socket\parser\DecodingException.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */