/*    */ package io.socket.client;
/*    */ 
/*    */ 
/*    */ public class SocketIOException
/*    */   extends Exception
/*    */ {
/*    */   public SocketIOException() {}
/*    */   
/*    */   public SocketIOException(String message) {
/* 10 */     super(message);
/*    */   }
/*    */   
/*    */   public SocketIOException(String message, Throwable cause) {
/* 14 */     super(message, cause);
/*    */   }
/*    */   
/*    */   public SocketIOException(Throwable cause) {
/* 18 */     super(cause);
/*    */   }
/*    */ }


/* Location:              D:\Users\imnot\OneDrive\Desktop\test\hello\module_example-0.1-26.1-0.15.4-mc1.12.1_deobfuscated.jar!\io\socket\client\SocketIOException.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */