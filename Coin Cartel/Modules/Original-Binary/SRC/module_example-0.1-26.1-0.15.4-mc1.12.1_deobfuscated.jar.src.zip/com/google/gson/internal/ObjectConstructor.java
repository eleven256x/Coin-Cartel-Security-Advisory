package com.google.gson.internal;

public interface ObjectConstructor<T> {
  T construct();
}


/* Location:              D:\Users\imnot\OneDrive\Desktop\test\hello\module_example-0.1-26.1-0.15.4-mc1.12.1_deobfuscated.jar!\com\google\gson\internal\ObjectConstructor.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */